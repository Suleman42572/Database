global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['923466586515']
global.gambar = "https://files.catbox.moe/pg8wee.jpg"